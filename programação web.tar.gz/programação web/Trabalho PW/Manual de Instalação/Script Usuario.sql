CREATE USER 'ctutoriais'@'localhost' IDENTIFIED BY 'passwd';
GRANT ALL PRIVILEGES ON * . * TO 'ctutoriais'@'localhost';
FLUSH PRIVILEGES;