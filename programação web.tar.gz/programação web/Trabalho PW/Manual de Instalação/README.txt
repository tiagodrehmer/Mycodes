A aplica��o foi desenvolvida usando a IDE NetBeans 8.1.

Usamos o Composer para gerenciar as dependencias de classes, o instalador da ferramenta se
encontra na pasta caso nescess�rio.

Para rodar a aplica��o primeiro � preciso configurar/criar a base de dados, para isso basta 
executar os scripts SQL que se encontram nessa pasta na seguinte ordem:

1 - Script Usuario
2 - Script Forum Database

Feito isso basta executar o arquivo index.php em CTutoriais/View
